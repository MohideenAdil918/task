
  # Convert to React Native

  This is a code bundle for Convert to React Native. The original project is available at https://www.figma.com/design/SBF1JjNZ7bEmkJv3Ln788f/Convert-to-React-Native.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  